// Common for js and typescript and nodejs

function myFunc(p1, p2) {
    setInterval(() => {
        return p1 + p2;
    }, 1000);
}

var res = myFunc(10, 20);
console.log(res);//ud; myFunc has an async operation

// Then how to return a value from a async function ???

Promises:
--Handle any async operation
--4 stages
--At a particular point of time a promise can be only in one of the stages
--pending, resolved, rejected, fulfilled
--promise resolved(async op is successful)
--promise rejected(async op has failed)
--pending stage(async is running)
--fulfilled stage(promise has been resolved or rejected)

function myFunc1(p1) {
    console.log("Inside set Interval");
    if (p1 % 2 == 0) {
        // return its an even number
        //return "even";// not able to access
        return Promise.resolve("even")
    }
    else {
        // return "odd";
        // return a failure 
        return Promise.reject(`${p1} is not an even number`);
    }

}
//var res=myFunc1(10);// no ; returning a promise
myFunc1(10)
    .then((data) => {
        console.log("Promise resolved with the data", data)
    }) // promise is resolved; implicitly execute the callback associated with the "then"
    .catch((err) => {
        console.log("Promise rejected with the error : " + err)
    })//// promise is rejected; implicitly execute the callback associated with the "catch"
After 5 sec:
Inside set Interval
Promise resolved with the data even

myFunc1(11)
    .then((data) => {
        console.log("Promise resolved with the data", data)
    }) // promise is resolved; implicitly execute the callback associated with the "then"
    .catch((err) => {
        console.log("Promise rejected with the error : " + err)
    })//// promise is rejected; implicitly execute the callback associated with the "catch"
After 5 sec:
Inside set Interval
Promise rejected with the error: 11 is not an even number



function myFunc2(p1) {

    var myPromise = new Promise((resolve, reject) => {
        setInterval(() => {
            if (p1 % 2 == 0) {
                // return its an even number
                //return "even";// not able to access
                return resolve("even")
            }
            else {
                // return "odd";
                // return a failure 
                return reject(`${p1} is not an even number`);
            }
                     }, 5000)
                });
                return myPromise;
            
            }
            myFunc2(11)
                .then((data) => {
                    console.log("Promise resolved with the data", data)
                }) // promise is resolved; implicitly execute the callback associated with the "then"
                .catch((err) => {
                    console.log("Promise rejected with the error : " + err)
                })//// promise is rejected; implicitly execute the callback associated with the "catch"
            
            In Es6-- async and await
            
            --2 keywords along with promises
            --await is added to async function call or to a function which returns a promise
            --await should always be enclosed inside an async function
             */
            async function myFunc3() {
                try {
                    var d1 = myFunc2(10);
                    console.log(typeof d1);// promise
                    console.log(d1);// promise(pending)
                    var data = await myFunc2(10);// data will get populated if promise gets resolved
                    console.log(data);//"even"

                    var d2 = await myFunc2(11);// promise will be rejected; throw an error
                    console.log(d2);//control flow will never come here
                }
                catch (err) {
                    console.log(err);//
                }
            }