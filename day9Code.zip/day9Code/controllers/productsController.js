var Products=require("../model/Products");

var productsArr = [
    new Products(1001, "Monitor", 20000, 10, "computer"),
    new Products(1001, "Monitor", 20000, 10, "computer"),
    new Products(1002, "Keyboard", 2000, 5, "computer"),
    new Products(1003, "Mouse", 500, 20, "computer"),
    new Products(1004, "CPU", 15000, 5, "computer"),
    new Products(1005, "Speakers", 3000, 25, "computer"),
    new Products(1006, "Charger", 1000, 30, "mobile"),
    new Products(1007, "Headset", 2000, 10, "mobile")
];    
getAllProducts=function(){
    return productsArr;
    
}
updateProduct=function(productIdToBeUpdated,updatedData){
    var pos=productsArr.findIndex(item => item.productId == productIdToBeUpdated)
    console.log("pos :",pos)
    if(pos >=0)
    {
        productsArr.splice(pos,1,updatedData);
        return true;
    }
    else
    {
        return false;
    }
}

function deleteProduct(productIdToBeDeleted)
{
    var pos=productsArr.findIndex(item => item.productId == productIdToBeDeleted)
    console.log("pos :",pos)
    if(pos >=0)
    {
        productsArr.splice(pos,1);
        return true;
    }
    else
    {
        return false;
    }
}

module.exports={getAllProducts,deleteProduct,updateProduct}