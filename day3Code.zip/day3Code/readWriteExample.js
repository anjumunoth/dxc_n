// Read the contents from file1 and store it in file5
var fs=require("fs");
var myData="";
var result=fs.readFile("file1.txt",function(err,fileContent){

    if(err)
    {
        console.log("Error while reading the file ",err)
         
    }
    else
    {
        console.log("data read successfully");
         myData=fileContent;
         fs.writeFile("file5.txt",myData,(err)=>{
            if(err)
            {
                console.log("Error writing in the file",err)
            }
            else
            {
                console.log("data written successfully");
            }
        })
        
    }
})

console.log("Result : ",result);// ud( Because result is declared but not assigned a value) ;
/*
fs.readFile -- async op -- sent to the NOde Api
console.log(result);// ud
main() fn execution over;
callback queue will be dequeued
callback of readFile  will be executed
populate fileContent with the data read;
readFile () does not return anything; will fileContent be accessible outside fs.readFile -- NO

*/

