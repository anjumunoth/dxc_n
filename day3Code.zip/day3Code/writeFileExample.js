var fs=require("fs");

fs.writeFile("text3.txt","This is the new contents of file3",function(err){
    console.log("Write operation completed");
    if(err)
    {
        console.log("Error",err);
    }
    else
    {
        console.log("Write operation completed successfully");
    }
    
})