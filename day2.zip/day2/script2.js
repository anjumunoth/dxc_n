// Call back function

function myFunc() {
    console.log("Start");
    setInterval(() => {
        console.log("Async op");
    }, 5000)
    console.log("End")
}
myFunc();// Start;End; Async Op; Async Op; Async Op

//Asynchronous function Examples : setInterval, give a request to the server; read/write of files; I/O operation

function myFunc1(p1, f1) {
    // perform a async op
    var ctr = 0
    var clearIntervalId = setInterval(() => {
        ctr++;
        if (ctr == 5) {
            clearInterval(clearIntervalId);
            if (p1 % 2 == 0) {
                f1(null, "success");
            }
            else {
                f1(`${p1} is not an even number`, null);
            }
        }
    }, 3000);

}

myFunc1(101, function myCallBack(err, data) {
    if (err) {
        console.log("Error : " + err);
    }
    else {
        console.log("MyFunc executed successfully with the data : " + data);
    }
})

setInterval(() => {
    var p1Ref = document.getElementById("p1");
    p1Ref.style.backgroundColor = "pink";
    p1Ref.style.color = "red";
    p1Ref.innerHTML = "Hello Spring People"

}, 15000)

/*
Callback Function
 -- Executed on the completion of the function called
 -- First parameter will have the error parameter
 -- Either error is populated or data is populated
 -- Usage -- perform operations on the completion of function excution
*/

// function myFunc2(callBackFunction)
// {
//     // give the Get request to the REST API
//     // Once the response received
//     // If response is success
//     callBackFunction(null,data);
//     // If response is a failure
//     callBackFunction(err,null);

// }

// Destructuring an object -- {}

var emp1={empId:101,empName:"sara",salary:890}

var i,j=10;
console.log(i);//undefined

var emp2=emp1;// creating a reference

var {empId,empName}=emp1;// destructuring an object; variable name and field name should be same
console.log(empId);
console.log(empName);

// Destructure an array -- based on the position
var arr1=[10,20,30,40,50];
var [first,second] =arr1;
console.log(first);//10
console.log(second);//20

var [n1,,n3] =arr1;
console.log(n1);//10
console.log(n3);//30

var [n1,,,,,,,n2]=arr1;
console.log(n2);//ud

var empArr=[
    {empId:101,empName:"Sara",projectId:"P101"},
    {empId:102,empName:"Keshav",projectId:"P101"},
    {empId:103,empName:"Saurabh",projectId:"P102"},
    {empId:104,empName:"Giri",projectId:"P102"},
    {empId:105,empName:"Saraansh",projectId:"P103"},
    {empId:106,empName:"Puja",projectId:"P104"},
    {empId:107,empName:"Neha",projectId:"P104"},
    {empId:108,empName:"Priyam",projectId:"P105"},
    {empId:109,empName:"Pranav",projectId:"P105"},
    {empId:110,empName:"Puja",projectId:"P104"}];

var [empAtPos0]=empArr;

var {empName,empId}=empAtPos0;

console.log(empName);//Sara

var [{empId},{empName},{projectId}]=empArr;
console.log(empId);//101
console.log(empName);//Keshav
console.log(projectId);//P102

    







